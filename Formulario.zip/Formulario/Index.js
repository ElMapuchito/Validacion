/*
const expresiones = {
	usuario: /^[a-zA-Z0-9\_\-]{4,16}$/,
	nombre: /^[a-zA-ZÀ-ÿ\s]{1,40}$/,
	password: /^.{4,12}$/,
	correo: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/,
	telefono: /^\d{7,14}$/
}

//Variable principales
const formulario = document.getElementById('formulario');
const inputs = document.querySelectorAll('#formulario input');

//Funciones
const validarFormulario = (e) => {
    switch (e.target.name) {
        case 'name':
            if(expresiones.usuario.test(e.target.value)){
                console.log('poto')
            } else {
                document.getElementById('form_usuario').classList.add('formulario_incorrecto')
                console.log('esta mal')
            }
        break;
        case 'email':
            console.log('owo')
        break;
        case 'pass-1':
            console.log('owoo')
        break;
        case 'pass-2':
            console.log('Owoooo')
        break;
    }
};

//Comandos de funcion
inputs.forEach((input) => {
    input.addEventListener('keyup', validarFormulario);
    input.addEventListener('blur', validarFormulario);
});

formulario.addEventListener('button-enviar', (e) => {
    e.preventDefault();
});
*/

(function () {
    'use strict'

    var forms = document.querySelectorAll('.needs-validation')

    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
      .forEach(function (form) {
        form.addEventListener('submit', function (event) {
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }
          form.classList.add('was-validated')
        })
      })
  })()